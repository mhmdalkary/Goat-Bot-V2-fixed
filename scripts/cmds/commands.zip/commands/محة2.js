const DIG = require("discord-image-generation");
const fs = require("fs-extra");

module.exports = {
  config: {
    name: "محة2",
    version: "1.2",
    author: "sandy",
    countDown: 5,
    role: 0,
    shortDescription: "أرسل قبلة لشخص",
    longDescription: "اصنع صورة قبلة بينك وبين الشخص المذكور أو المرد عليه برسالة مختلفة كل مرة",
    category: "حب",
    guide: "{pn} @اسم_الشخص أو الرد على رسالته"
  },

  onStart: async function ({ event, message, usersData, args }) {
    const uid1 = event.senderID;
    let uid2;

    // إذا ذكر شخص
    const mention = Object.keys(event.mentions);
    if (mention.length > 0) uid2 = mention[0];
    // إذا الرد على رسالة
    else if (event.messageReply && event.messageReply.senderID) uid2 = event.messageReply.senderID;
    // لا يوجد شخص
    else return message.reply("يرجى ذكر شخص أو الرد على رسالته لإرسال القبلة");

    const avatarURL1 = await usersData.getAvatarUrl(uid1);
    const avatarURL2 = await usersData.getAvatarUrl(uid2);

    const img = await new DIG.Kiss().getImage(avatarURL1, avatarURL2);
    const pathSave = `${__dirname}/tmp/${uid1}_${uid2}Kiss.png`;
    fs.writeFileSync(pathSave, Buffer.from(img));

    // رسائل مختلفة كل مرة
    const messages = [
      "mwuahh 😘😘",
      "قبلة رومانسية 😚💖",
      "هاك قبلة 😘💌",
      "قبلة حارة 🔥😘",
      "مسة حب 😘💕"
    ];
    const randomMsg = messages[Math.floor(Math.random() * messages.length)];

    message.reply({
      body: randomMsg,
      attachment: fs.createReadStream(pathSave)
    }, () => fs.unlinkSync(pathSave));
  }
};