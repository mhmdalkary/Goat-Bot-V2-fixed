const { getPrefix } = global.utils;
const { commands } = global.GoatBot;

module.exports = {
  config: {
    name: "اوامر",
    aliases: ["الاوامر", "أوامر"],
    version: "5.6",
    author: "محمد",
    countDown: 5,
    role: 0,
    shortDescription: { ar: "عرض قائمة الأوامر" },
    longDescription: { ar: "عرض الأوامر مع صفحات وزخارف تشبه النسخة السابقة" },
    category: "info",
    guide: { ar: "{pn} [رقم الصفحة]" }
  },

  onStart: async function ({ message, args, event }) {
    const { threadID, senderID } = event;
    const prefix = getPrefix(threadID);

    let userRole = 0;
    if (event.isGroupAdmin) userRole = 1;
    if (global.GoatBot.config.owners?.includes(senderID)) userRole = 2;

    const allCommands = Array.from(commands.values())
      .filter(cmd => cmd.config.category && !["العاب","لعبة فردية","لعبة ثنائية","لعبة جماعية","المطور"].includes(cmd.config.category))
      .filter(cmd => cmd.config.role <= userRole);

    if (!allCommands.length) return message.reply("❌ ما في أوامر متاحة");

    const itemsPerPage = 40;
    const totalPages = Math.ceil(allCommands.length / itemsPerPage);
    const page = Math.max(1, Math.min(parseInt(args[0]) || 1, totalPages));

    const start = (page - 1) * itemsPerPage;
    const end = start + itemsPerPage;
    const list = allCommands.slice(start, end);

    let msg = 
`╮─━─━─━─━─━─━─━─╭
       𝑬𝒍𝒊 - 𝑪𝒎𝒅𝒔
╯─━─━─━─━─━─━─━─╰
📄 الصفحة: ${page}/${totalPages}
─────────────────\n`;

    list.forEach((cmd) => {
      const aliases = cmd.config.aliases?.length ? ` (${cmd.config.aliases.join(", ")})` : "";
      msg += `▸ | ${cmd.config.name}${aliases}\n`;
    });

    msg += 
`\n─────────────────
✦ ملاحظات ✦
• لتحميل فيديو: أرسل الرابط مباشرة  
• لبدء محادثة ممتعة أكتب ايلي "رسالتك" 
• لشرح أمر أكتب شرح "أسم الأمر"
─────────────────

╮─•° المـالِـك °•─╭
 https://m.me/ukidn`;

    return message.reply(msg);
  }
};