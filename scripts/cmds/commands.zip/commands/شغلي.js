module.exports = {
  config: {
    name: "sing",
    version: "1.1",
    role: 0,
    author: "kshitiz | fix: SIFO ANTER",
    cooldowns: 5,
    shortdescription: "تنزيل موسيقى من يوتيوب",
    longdescription: "ابحث عن أغنية من يوتيوب وأرسلها كملف صوتي.",
    category: "music",
    usages: "{pn} اسم_الأغنية",
    dependencies: {
      "fs-extra": "",
      "ytdl-core": "",
      "yt-search": ""
    }
  },

  onStart: async ({ api, event, args }) => {
    const fs = require("fs-extra");
    const ytdl = require("ytdl-core");
    const yts = require("yt-search");

    try {
      const body = (event.body || "").trim();
      const musicName = (args && args.length) ? args.join(" ") : body.split(/\s+/).slice(1).join(" ");

      if (!musicName) {
        return api.sendMessage("يرجى تحديد اسم الأغنية.", event.threadID, event.messageID);
      }

      await api.sendMessage(`جارٍ البحث عن: "${musicName}"...`, event.threadID, event.messageID);

      const searchResults = await yts(musicName);
      if (!searchResults.videos || !searchResults.videos.length) {
        return api.sendMessage("لم يتم العثور على أي نتيجة للأغنية المطلوبة.", event.threadID, event.messageID);
      }

      const music = searchResults.videos[0];
      const musicUrl = music.url;

      const cacheDir = __dirname + "/cache";
      await fs.ensureDir(cacheDir);

      const fileName = `${event.senderID}.mp3`;
      const filePath = `${cacheDir}/${fileName}`;

      const stream = ytdl(musicUrl, {
        filter: "audioonly",
        quality: "highestaudio",
        highWaterMark: 1 << 25
      });

      const writeStream = fs.createWriteStream(filePath);
      stream.pipe(writeStream);

      stream.on("error", () => {
        try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
        api.sendMessage("حدث خطأ أثناء تحميل الصوت من يوتيوب.", event.threadID, event.messageID);
      });

      writeStream.on("error", () => {
        try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
        api.sendMessage("حدث خطأ أثناء حفظ الملف الصوتي.", event.threadID, event.messageID);
      });

      writeStream.on("finish", async () => {
        try {
          const stats = await fs.stat(filePath);
          if (stats.size > 26214400) {
            await fs.unlink(filePath);
            return api.sendMessage("❌ لا يمكن إرسال الملف لأنه أكبر من 25 ميجابايت.", event.threadID, event.messageID);
          }

          const message = {
            body: `تم العثور على الأغنية:\nالعنوان: ${music.title}\nالمدة: ${music.duration.timestamp}`,
            attachment: fs.createReadStream(filePath)
          };

          api.sendMessage(message, event.threadID, () => {
            fs.unlink(filePath).catch(() => {});
          });
        } catch {
          try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
          api.sendMessage("حدث خطأ أثناء معالجة الملف الصوتي.", event.threadID, event.messageID);
        }
      });

    } catch {
      api.sendMessage("حدث خطأ غير متوقع أثناء تنفيذ الأمر.", event.threadID, event.messageID);
    }
  }
};