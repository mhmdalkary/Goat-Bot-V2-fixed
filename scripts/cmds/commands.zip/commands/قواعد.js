module.exports = {
  config: {
    name: "صلاحية",
    version: "1.4",
    author: "NTKhang + gpt",
    countDown: 5,
    role: 1,
    shortDescription: { ar: "تغيير من يمكنه إستعمال أمر أو تعديل قسم الأمر في مجموعتك" },
    longDescription: { ar: "تعديل صلاحية أو قسم أوامر أدمن المجموعة والمستخدم فقط 😐" },
    category: "إدارة المجموعة",
    guide: {
      ar:
`▸ *كيفية الاستخدام:*  
▸ صلاحية <اسم_الأمر> <رقم_الصلاحية_أو_default>  
   - رقم الصلاحية:  
     0: للجميع  
     1: للأدمن فقط  
     default: لإعادة الإعداد الافتراضي  

▸ صلاحية قسم <اسم_الأمر> <القسم_الجديد>  
   - لتغيير قسم الأمر داخل البوت`
    }
  },

  langs: {
    ar: {
      noEditedCommand: "▸ *لم يتم تعديل أي أمر بعد في مجموعتك*",
      editedCommand: "▸ *أوامر مجموعتك المعدلة:*",
      noPermission: "▸ *ما عندك صلاحية لتعديل الأوامر* ▸ يرجى طلب رتبة أدمن",
      commandNotFound: "▸ *الأمر \"%1\" غير موجود* ▸ تأكد من الاسم الصحيح",
      noChangeRole: "▸ *لا يمكنك تعديل صلاحية هذا الأمر* ▸ (مخصص للنظام فقط)",
      resetRole: "▸ *تمت إعادة صلاحية الأمر \"%1\" للوضع الافتراضي* ▸ وفق إعدادات النظام",
      changedRole: "▸ *تم تغيير صلاحية الأمر \"%1\" إلى %2 (%3)*",
      changedCategory: "▸ *تم تغيير قسم الأمر \"%1\" إلى \"%2\"* ▸ لترتيب أوامر البوت بشكل أفضل"
    }
  },

  onStart: async function ({ message, event, args, role, threadsData, getLang }) {
    const { commands, aliases } = global.GoatBot;
    const setRole = await threadsData.get(event.threadID, "data.setRole", {});
    const setCategory = await threadsData.get(event.threadID, "data.setCategory", {});

    if (!args[0]) return message.SyntaxError();

    function formatLang(text, ...params) {
      let formatted = text;
      params.forEach((val, i) => {
        const re = new RegExp(`%${i + 1}`, "g");
        formatted = formatted.replace(re, val);
      });
      return formatted;
    }

    if (["view", "viewrole", "show", "رؤيةصلاحيات", "رؤية", "عرض"].includes(args[0].toLowerCase())) {
      if ((!setRole || Object.keys(setRole).length === 0) && (!setCategory || Object.keys(setCategory).length === 0))
        return message.reply(getLang("noEditedCommand"));

      let msg = getLang("editedCommand");
      if (setRole && Object.keys(setRole).length > 0) {
        msg += "\n▸ *صلاحيات الأوامر:*";
        for (const cmd in setRole) msg += `\n▸ ${cmd} => ${setRole[cmd]}`;
      }
      if (setCategory && Object.keys(setCategory).length > 0) {
        msg += "\n▸ *أقسام الأوامر:*";
        for (const cmd in setCategory) msg += `\n▸ ${cmd} => ${setCategory[cmd]}`;
      }
      return message.reply(msg);
    }

    if (args[0].toLowerCase() === "قسم") {
      if (role < 1) return message.reply(getLang("noPermission"));
      const commandName = (args[1] || "").toLowerCase();
      const newCategory = args.slice(2).join(" ");
      if (!commandName || !newCategory) return message.SyntaxError();

      const command = commands.get(commandName) || commands.get(aliases.get(commandName));
      if (!command) return message.reply(formatLang(getLang("commandNotFound"), commandName));

      setCategory[command.config.name] = newCategory;
      await threadsData.set(event.threadID, setCategory, "data.setCategory");
      return message.reply(formatLang(getLang("changedCategory"), command.config.name, newCategory));
    }

    const commandName = (args[0] || "").toLowerCase();
    let newRole = args[1];
    if (!commandName || (isNaN(newRole) && newRole !== "default")) return message.SyntaxError();
    if (role < 1) return message.reply(getLang("noPermission"));

    const command = commands.get(commandName) || commands.get(aliases.get(commandName));
    if (!command) return message.reply(formatLang(getLang("commandNotFound"), commandName));
    const cmdName = command.config.name;
    if (command.config.role > 1) return message.reply(getLang("noChangeRole"));

    let Default = false;
    if (newRole === "default" || newRole == command.config.role) {
      Default = true;
      newRole = command.config.role;
    } else {
      newRole = parseInt(newRole);
    }

    const setRoleUpdated = {...setRole};
    if (Default) delete setRoleUpdated[cmdName];
    else setRoleUpdated[cmdName] = newRole;

    await threadsData.set(event.threadID, setRoleUpdated, "data.setRole");

    let roleText = newRole == 0 ? "للجميع" : newRole == 1 ? "للأدمن فقط" : newRole;

    return message.reply(
      Default
        ? formatLang(getLang("resetRole"), cmdName)
        : formatLang(getLang("changedRole"), cmdName, newRole, roleText)
    );
  }
};