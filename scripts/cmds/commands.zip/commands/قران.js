const fetch = require('node-fetch');
const fs = require('fs');
const request = require('request');

async function getQuranVerse({ api, event, args }) {
  try {
    // جلب معلومات كل السور
    const surahRes = await fetch('https://api.quran.gading.dev/surah');
    const surahData = await surahRes.json();
    const surahs = surahData.data; // مصفوفة كل السور

    let s1 = args[0];
    let s2 = args[1];

    // لو ما حط المستخدم أرقام، يختار سورة وآية عشوائية
    if (!s1 || !s2) {
      const randomSurah = surahs[Math.floor(Math.random() * surahs.length)];
      s1 = randomSurah.number;
      const ayahCount = randomSurah.numberOfAyahs;
      s2 = Math.floor(Math.random() * ayahCount) + 1;
    }

    const url = `https://api.quran.gading.dev/surah/${s1}/${s2}`;
    const response = await fetch(url);
    const data = await response.json();

    const audioLink = data.data.audio.secondary[0];

    request({ url: audioLink, encoding: null }, function (error, response, body) {
      if (error) throw error;
      fs.writeFileSync(__dirname + '/cache/quran_aud.mp3', body);
      api.sendMessage(
        {
          body: `📖 القرآن - سورة ${data.data.surah.name.transliteration.id} - آية ${s2}\n\n${data.data.text.arab}`,
          attachment: fs.createReadStream(__dirname + `/cache/quran_aud.mp3`)
        },
        event.threadID,
        () => fs.unlinkSync(__dirname + `/cache/quran_aud.mp3`),
        event.messageID
      );
    });

  } catch (error) {
    console.error('حدث خطأ:', error);
    api.sendMessage('عذراً، حدث خطأ أثناء جلب الآية', event.threadID, event.messageID);
  }
}

module.exports = {
  config: {
    name: "قرآن",
    version: "1.2",
    author: "حسين يعقوبي",
    countDown: 5,
    role: 0,
    shortDescription: {
      en: "يرسل آية قرآنية مع الصوت"
    },
    longDescription: {
      en: "يمكنك إما تحديد السورة والآية أو تركها للبوت ليختار آية عشوائية"
    },
    category: "إسلام",
    guide: {
      en: "{pn} [رقم_السورة رقم_الآية] أو {pn} للآية العشوائية"
    }
  },
  onStart: getQuranVerse,
};