const fs = require('fs');
const path = require('path');

module.exports = {
  config: {
    name: "لغز",
    version: "1.3",
    author: "Shikaki",
    role: 0,
    reward: Math.floor(Math.random() * (100 - 50 + 1) + 50),
    category: "لعبة فردية",
    shortDescription: { ar: "احصل على لغز وحاول تحله للفوز" },
    longDescription: { ar: "احصل على لغز من الملف وحاول تجاوب عليه للفوز بالجائزة" },
    guide: { ar: "{prefix}لغز" }
  },

  onReply: async function ({ event, api, Reply, usersData }) {
    if (event.senderID !== Reply.author || Reply.type !== "reply") return;

    // عد المحاولات
    Reply.attempts = Reply.attempts ? Reply.attempts + 1 : 1;

    const userAnswer = event.body.trim().toLowerCase();
    const correctAnswer = Reply.answer.toLowerCase();

    if (userAnswer === correctAnswer) {
      const reward = Math.floor(Math.random() * (100 - 50 + 1) + 50);
      await usersData.addMoney(event.senderID, reward);
      global.GoatBot.onReply.delete(Reply.messageID);
      return api.sendMessage(
        `▸ *مبروك!*    
│ الإجابة صحيحة  
▸ لقد فزت ب ${reward} فيلور 💰`, 
        event.threadID
      );
    }

    if (Reply.attempts >= 3) {
      global.GoatBot.onReply.delete(Reply.messageID);
      return api.sendMessage(
        `▸ *محاولاتك انتهت*    
│ الإجابة الصحيحة: ${Reply.answer}`, 
        event.threadID
      );
    }

    api.sendMessage(`▸ *محاولة خاطئة*    
│ حاول مرة أخرى (محاولة ${Reply.attempts}/3)`, event.threadID);
  },

  onStart: async function ({ api, event }) {
    const { threadID } = event;
    const filePath = path.join(__dirname, 'Offices', 'riddles.json');
    const riddles = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const randomRiddle = riddles[Math.floor(Math.random() * riddles.length)];
    const { riddle, answer } = randomRiddle;

    const startMsg =
`▸ **لغز جديد!**    
▸ حاول تجاوب على اللغز التالي  
▸ اللغز: "${riddle}"    
▸ لديك 3 محاولات فقط`;

    api.sendMessage({ body: startMsg }, threadID, async (error, info) => {
      global.GoatBot.onReply.set(info.messageID, {
        type: "reply",
        commandName: "لغز",
        author: event.senderID,
        messageID: info.messageID,
        answer,
        attempts: 0
      });
    });
  }
};