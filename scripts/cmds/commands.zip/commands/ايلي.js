const axios = require("axios")
const fs = require("fs")
const path = require("path")

const cachePath = path.join(__dirname, 'chatHistory.json')
if (!fs.existsSync(cachePath)) fs.writeFileSync(cachePath, "{}")

function loadHistory() {
  try {
    const data = fs.readFileSync(cachePath, "utf8")
    return JSON.parse(data)
  } catch {
    return {}
  }
}

function saveHistory(history) {
  fs.writeFileSync(cachePath, JSON.stringify(history, null, 2))
}

async function sendToGPT(messages) {
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: `إنت "ايلي"، خليجية لطيفة، حنينة شوي، بس عندك طابع شقاوة وخفة دم، ترد بالعامية الخليجية، مرحة، وتحب تضحك على المواقف بس بدون إساءة حقيقية`
          },
          ...messages
        ]
      },
      {
        headers: {
          'Authorization': 'Bearer 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',
          'Content-Type': 'application/json'
        }
      }
    )
    let reply = response.data.choices[0].message.content.trim()
    if (!reply) {
      const randomReplies = [
        "هااااااي حبيبي، شسويت اليوم؟",
        "يا هلا والله، ضحكتك اليوم وين راحت؟",
        "أبد، ماكو شي، بس حبيت أسولف وياك شوي"
      ]
      reply = randomReplies[Math.floor(Math.random() * randomReplies.length)]
    }
    return reply
  } catch {
    return null
  }
}

module.exports = {
  config: {
    name: "ايلي",
    aliases: ["chat", "gpt"],
    version: "4.0",
    author: "R3D",
    countDown: 5,
    role: 0,
    shortDescription: "ايلي الخليجية المرحة",
    longDescription: "بوت يرد بالعامية الخليجية بخفة دم ولطافة",
    category: "محادثة",
    guide: "{pn} <نص> أو رد على رسالة ايلي"
  },
  onStart: async function ({ message, event, args }) {
    const { threadID, senderID, messageReply } = event
    let userInput = args.join(" ").trim()

    const history = loadHistory()
    const sessionKey = `${senderID}_${threadID}`
    if (!history[sessionKey]) history[sessionKey] = []

    if (userInput) {
      history[sessionKey].push({ role: "user", content: userInput })
    } else {
      history[sessionKey].push({ role: "user", content: " " })
    }

    try {
      const replyText = await sendToGPT(history[sessionKey])
      if (!replyText) throw new Error()
      history[sessionKey].push({ role: "assistant", content: replyText })
      saveHistory(history)

      const sentMessage = await message.reply(replyText)
      global.GoatBot.onReply.set(sentMessage.messageID, {
        commandName: "ايلي",
        author: senderID,
        threadID: threadID,
        sessionKey: sessionKey
      })
    } catch {
      message.reply("ايلي ما قدرت ترد هالمرة")
    }
  },
  onReply: async function ({ message, event, Reply }) {
    const { senderID, threadID, body } = event
    const { author, sessionKey } = Reply
    if (senderID !== author || threadID !== Reply.threadID) return

    const history = loadHistory()
    if (!history[sessionKey]) history[sessionKey] = []

    const userInput = body.trim() || " "
    history[sessionKey].push({ role: "user", content: userInput })

    try {
      const replyText = await sendToGPT(history[sessionKey])
      if (!replyText) throw new Error()
      history[sessionKey].push({ role: "assistant", content: replyText })
      saveHistory(history)

      const sentMessage = await message.reply(replyText)
      global.GoatBot.onReply.set(sentMessage.messageID, {
        commandName: "ايلي",
        author: senderID,
        threadID: threadID,
        sessionKey: sessionKey
      })
    } catch {
      message.reply("ايلي سكتت، يمكن استحيت شوي")
    }
  }
}