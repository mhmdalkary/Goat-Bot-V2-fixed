const fs = require('fs');

module.exports = {
  config: {
    name: "صراحة",
    version: "1.0",
    author: "Loid Butter",
    countDown: 5,
    role: 0,
    shortDescription: "احصل على سؤال صراحة عشوائي",
    longDescription: "هذا الأمر يعطيك سؤال صراحة من القائمة.",
    category: "لعبة",
    guide: {
      ar: "{pn} صراحة"
    }
  },

  onStart: async function ({ message }) {
    const truthQuestions = JSON.parse(fs.readFileSync("TRUTHQN.json"));
    const randomIndex = Math.floor(Math.random() * truthQuestions.length);
    const randomQuestion = truthQuestions[randomIndex];

    message.reply(` سؤال صراحة: ${randomQuestion}`);
  }
}