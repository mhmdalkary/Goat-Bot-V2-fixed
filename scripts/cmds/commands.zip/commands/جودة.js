const axios = require("axios");
const FormData = require("form-data");
const fs = require('fs');
const path = require('path');

module.exports = {
  config: {
    name: "جودة",
    aliases: ["upscale", "quality"],
    version: "1.0",
    author: "Assistant",
    countDown: 10,
    role: 0,
    description: {
      ar: "تحسين جودة الصورة باستخدام الذكاء الاصطناعي",
      en: "Upscale image quality using AI"
    },
    category: "الذكاء الصناعي",
    guide: {
      en: "{pn} [2|4] - قم بالرد على صورة أو إرفاق صورة\n" +
           "2 = تكبير 2x\n" +
           "4 = تكبير 4x\n" +
           "مثال: {pn} 4",
      vi: "{pn} [2|4] - Reply to an image or attach an image\n" +
           "2 = 2x upscale\n" +
           "4 = 4x upscale\n" +
           "Example: {pn} 4"
    }
  },

  onStart: async function({ message, args, event, api }) {
    try {
      // التحقق من وجود صورة
      let imageUrl = null;
      
      // البحث عن صورة في المرفقات
      if (event.messageReply && event.messageReply.attachments && event.messageReply.attachments.length > 0) {
        const attachment = event.messageReply.attachments[0];
        if (attachment.type === "photo") {
          imageUrl = attachment.url;
        }
      } else if (event.attachments && event.attachments.length > 0) {
        const attachment = event.attachments[0];
        if (attachment.type === "photo") {
          imageUrl = attachment.url;
        }
      }

      if (!imageUrl) {
        return message.reply("❌ يرجى الرد على صورة أو إرفاق صورة لتحسين جودتها!");
      }

      // تحديد مقياس التكبير (افتراضي 2)
      let scale = 2;
      if (args[0]) {
        const inputScale = parseInt(args[0]);
        if (inputScale === 2 || inputScale === 4) {
          scale = inputScale;
        } else {
          return message.reply("❌ المقياس يجب أن يكون 2 أو 4 فقط!");
        }
      }

      // إرسال رسالة التحميل
      const loadingMsg = await message.reply(`🔄 جاري تحسين جودة الصورة بمقياس ${scale}x...\n⏳ قد تستغرق هذه العملية بعض الوقت، يرجى الانتظار...`);

      // استدعاء وظيفة تحسين الجودة
      const upscaledUrl = await upscaleImage(imageUrl, scale);

      if (!upscaledUrl) {
        return message.reply("❌ فشل في تحسين جودة الصورة. يرجى المحاولة مرة أخرى.");
      }

      // تحميل الصورة المحسنة وإرسالها
      const fs = require('fs');
      const path = require('path');
      const { createWriteStream } = require('fs');
      
      // تحميل الصورة كـ stream
      const response = await axios({
        method: 'GET',
        url: upscaledUrl,
        responseType: 'stream'
      });

      // إنشاء مسار مؤقت للصورة
      const tempPath = path.join(__dirname, 'cache', `upscaled_${Date.now()}.jpg`);
      
      // إنشاء مجلد cache إذا لم يكن موجود
      const cacheDir = path.dirname(tempPath);
      if (!fs.existsSync(cacheDir)) {
        fs.mkdirSync(cacheDir, { recursive: true });
      }

      // كتابة الصورة إلى ملف مؤقت
      const writer = createWriteStream(tempPath);
      response.data.pipe(writer);

      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });

      // إرسال الصورة
      await message.reply({
        body: `✅ تم تحسين جودة الصورة بنجاح!\n📐 المقياس: ${scale}x`,
        attachment: fs.createReadStream(tempPath)
      });

      // حذف الملف المؤقت بعد الإرسال
      setTimeout(() => {
        if (fs.existsSync(tempPath)) {
          fs.unlinkSync(tempPath);
        }
      }, 5000);

    } catch (error) {
      console.error("خطأ في أمر جودة:", error);
      message.reply("❌ حدث خطأ أثناء معالجة الصورة. يرجى المحاولة مرة أخرى.");
    }
  }
};

// وظيفة تحسين جودة الصورة
async function upscaleImage(imgUrl, scale = 2) {
  const headers = {
    accept: "application/json, text/plain, */*",
    "accept-language": "ar,en;q=0.9",
    "cache-control": "no-cache",
    connection: "keep-alive",
    origin: "https://imgupscaler.com",
    pragma: "no-cache",
    referer: "https://imgupscaler.com/",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${generateChromeVersion()} Safari/537.36`,
    "sec-ch-ua": '"Chromium";v="131", "Not_A Brand";v="24", "Microsoft Edge";v="131"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"'
  };

  try {
    // تحميل الصورة
    const { data: buffer } = await axios.get(imgUrl, {
      responseType: "arraybuffer"
    });

    // إنشاء FormData
    const formData = new FormData();
    formData.append("myfile", Buffer.from(buffer), {
      filename: "upload.jpg",
      contentType: "image/jpeg"
    });
    formData.append("scaleRadio", scale.toString());

    // رفع الصورة
    const { data } = await axios.post(
      "https://get1.imglarger.com/api/UpscalerNew/UploadNew", 
      formData, 
      { headers: { ...headers, ...formData.getHeaders() } }
    );

    if (!data.data || !data.data.code) {
      throw new Error("فشل في رفع الصورة");
    }

    // انتظار معالجة الصورة
    const result = await pollTask(data.data.code, scale, headers);
    return result?.downloadUrls ? result.downloadUrls[0] : null;

  } catch (error) {
    console.error("خطأ في تحسين الصورة:", error.response?.data || error.message);
    return null;
  }
}

// وظيفة انتظار معالجة الصورة
async function pollTask(jobCode, scale, headers) {
  try {
    let attempts = 0;
    const maxAttempts = 60; // الحد الأقصى 5 دقائق

    while (attempts < maxAttempts) {
      const { data } = await axios.post(
        "https://get1.imglarger.com/api/UpscalerNew/CheckStatusNew",
        {
          code: jobCode,
          scaleRadio: scale
        },
        { headers }
      );

      if (data.code === 200 && data.data?.status === "success") {
        return data.data;
      }

      if (data.data?.status === "error") {
        throw new Error("فشل في معالجة الصورة");
      }

      // انتظار 5 ثوان قبل المحاولة التالية
      await new Promise(resolve => setTimeout(resolve, 5000));
      attempts++;
    }

    throw new Error("انتهت مهلة الانتظار");
  } catch (error) {
    console.error("خطأ في انتظار المعالجة:", error.response?.data || error.message);
    return null;
  }
}

// وظيفة توليد إصدار Chrome عشوائي
function generateChromeVersion() {
  const randomBetween = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
  const maybe = (probability, fallback = () => 0) => Math.random() < probability ? 0 : fallback();
  
  return `${randomBetween(118, 131)}.${maybe(0.85, () => randomBetween(0, 9))}.${maybe(0.6, () => randomBetween(1000, 9999))}.${maybe(0.7, () => randomBetween(0, 199))}`;
}